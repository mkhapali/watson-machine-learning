import urllib3, requests, json, os
from flask import Flask, render_template, request
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, RadioField, FloatField, IntegerField
from wtforms.validators import Required, Length, NumberRange
url = 'https://ibm-watson-ml.mybluemix.net'
username = '5015d396-50a5-46d2-ae64-cab816852e7f'
password = '3621d6f6-f18a-4eea-9cf4-b8ace4adca20'
scoring_endpoint = 'https://ibm-watson-ml.mybluemix.net/v3/wml_instances/cb5bd88b-ea9c-4854-b515-55339ef7be7f/published_models/b31e58c4-55ad-4490-8a2d-8a33ece3eefc/deployments/9355a5b1-f1fe-4996-9b8f-8eb1d0771da0/online'
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secretpassw0rd'
bootstrap = Bootstrap(app)
class TentForm(FlaskForm):
  Glucose = FloatField('Your Glucose')
  BloodPressure = FloatField('Your BloodPressure')
  Insulin = FloatField('Your Insulin')
  BMI = FloatField('Your BMI')
  Age = FloatField('Your Age', validators=[NumberRange(1,100)])
  submit = SubmitField('Submit')
@app.route('/', methods=['GET', 'POST'])
def index():
  form = TentForm()
  if form.validate_on_submit():
    Glucose = form.Glucose.data
    form.Glucose.data = ''
    BloodPressure = form.BloodPressure.data
    form.BloodPressure.data = ''
    Insulin = form.Insulin.data
    form.Insulin.data = ''
    BMI = form.BMI.data
    form.BMI.data = ''
    Age = form.Age.data
    form.Age.data = ''
    headers = urllib3.util.make_headers(basic_auth='{}:{}'.format(username, password))
    path = '{}/v3/identity/token'.format(url)
    response = requests.get(path, headers=headers)
    mltoken = "Bearer " + json.loads(response.text).get('token')
    scoring_header = {'Content-Type': 'application/json', 'Authorization': mltoken}
    payload = {"fields": ["Glucose","BloodPressure","Insulin","BMI", "Age"], "values": [[148, 72, 0, 33.6, 50]]}
    scoring = requests.post(scoring_endpoint, json=payload, headers=scoring_header)
    return render_template('score.html', form=form, scoring=scoring)
  return render_template('index.html', form=form)
port = os.getenv('PORT', '5000')
if __name__ == "__main__":
  app.run(host='0.0.0.0', port=int(port))
